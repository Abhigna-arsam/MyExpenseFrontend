import { useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import axios from "axios";

const Verify = () => {

  const [params] = useSearchParams();
  const navigate = useNavigate();

  useEffect(() => {

    const token = params.get("token");

    if (!token) return;

    axios
      .get(`http://localhost:9090/api/auth/verify?token=${token}`)
      .then(() => {
        alert("Email verified successfully");
        navigate("/login");
      })
      .catch((err) => {
        alert(err.response?.data || "Verification failed");
      });

  }, []);

  return <h2>Verifying your email...</h2>;
};

export default Verify;
