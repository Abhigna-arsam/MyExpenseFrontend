import App from "../App";

const Dashboard = () => {
  return <App />;
};

export default Dashboard;
