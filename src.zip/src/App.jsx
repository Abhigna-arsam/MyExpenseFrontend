import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement,
  LineElement, Title, Tooltip, Legend, Filler,
} from 'chart.js';
import './App.css';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler);

const App = () => {
  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem('transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [activeView, setActiveView] = useState('Dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [totals, setTotals] = useState({ income: 0, expense: 0, balance: 0 });

  useEffect(() => {
    localStorage.setItem('transactions', JSON.stringify(transactions));
    const income = transactions.filter(t => t.type === 'income').reduce((acc, curr) => acc + Number(curr.amount), 0);
    const expense = transactions.filter(t => t.type === 'expense').reduce((acc, curr) => acc + Number(curr.amount), 0);
    setTotals({ income, expense, balance: income - expense });
  }, [transactions]);

  const addTransaction = (data) => setTransactions([data, ...transactions]);
  const deleteTransaction = (id) => setTransactions(transactions.filter((t) => t.id !== id));

  const filteredTransactions = transactions.filter(t => 
    t.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getIcon = (category) => {
    const icons = {
      'Bitcoin': '₿', 'Shopify': '🛍️', 'Youtube': '📺', 
      'Salary': '💵', 'Medical': '🏥', 'Travel': '🌍'
    };
    return icons[category] || '💰';
  };

  const chartData = {
    labels: transactions.slice(0, 7).reverse().map((t) => t.date),
    datasets: [
      {
        label: 'Income',
        data: transactions.filter(t => t.type === 'income').map(t => t.amount),
        borderColor: '#42ad00',
        backgroundColor: 'rgba(66, 173, 0, 0.1)',
        tension: 0.4,
        fill: true,
      },
      {
        label: 'Expense',
        data: transactions.filter(t => t.type === 'expense').map(t => t.amount),
        borderColor: '#ff0000',
        backgroundColor: 'rgba(255, 0, 0, 0.1)',
        tension: 0.4,
        fill: true,
      },
    ],
  };

  return (
    <div className="app-container">
      <aside className="sidebar">
        <div className="user-profile">
          <div className="avatar">🧔</div>
          <div className="user-info"><h3>Mike</h3><p>Your Money</p></div>
        </div>
        <nav className="nav-menu">
          {['Dashboard', 'View Transactions', 'Incomes', 'Expenses'].map((item) => (
            <div key={item} className={`nav-item ${activeView === item ? 'active' : ''}`} onClick={() => setActiveView(item)}>
              {item}
            </div>
          ))}
        </nav>
        <div className="sign-out">↪ Sign Out</div>
      </aside>

      <main className="main-content">
        <div className="top-bar">
          <div className="search-box">
             <span className="search-icon">🔍</span>
             <input 
               type="text" 
               placeholder="Search transactions..." 
               onChange={(e) => setSearchTerm(e.target.value)}
             />
          </div>
        </div>

        {activeView === 'Dashboard' ? (
          <div className="dashboard-view">
            <h1>All Transactions</h1>
            <div className="dashboard-grid">
              <section className="chart-area">
                <Line data={chartData} options={{ responsive: true, maintainAspectRatio: false }} />
              </section>
              <section className="history-pane">
                <h3>Recent History</h3>
                {transactions.slice(0, 3).map(t => (
                  <div key={t.id} className={`recent-row ${t.type}`}>
                    {t.title} <span>{t.type === 'income' ? '+' : '-'}${t.amount}</span>
                  </div>
                ))}
              </section>
              <div className="stats-row">
                <div className="stat-puck">Total Income <h2>${totals.income}</h2></div>
                <div className="stat-puck">Total Expenses <h2>${totals.expense}</h2></div>
                <div className="stat-puck balance">Total Balance <h2>${totals.balance}</h2></div>
              </div>
            </div>
          </div>
        ) : (
          <div className="split-view">
            <h1>{activeView}</h1>
            <div className="total-indicator">
              Total {activeView}: <span className={activeView === 'Incomes' ? 'pos' : 'neg'}>
                {activeView === 'Incomes' ? '' : '-'}${activeView === 'Incomes' ? totals.income : totals.expense}
              </span>
            </div>
            <div className="split-layout">
              <div className="form-column">
                <TransactionForm type={activeView === 'Incomes' ? 'income' : 'expense'} onAdd={addTransaction} />
              </div>
              <div className="list-column">
                {filteredTransactions
                  .filter((t) => t.type === (activeView === 'Incomes' ? 'income' : 'expense'))
                  .map((t) => (
                    <div key={t.id} className="item-pill">
                      <div className="pill-icon-box">{getIcon(t.category)}</div>
                      <div className="pill-body">
                        <div className="pill-top">
                           <span className={`status-dot ${t.type}`}></span>
                           <strong>{t.title}</strong>
                        </div>
                        <div className="pill-bottom">
                          <span>${t.amount}</span>
                          <span>📅 {t.date}</span>
                          <span className="ref-txt">💬 {t.reference || '...'}</span>
                        </div>
                      </div>
                      <button onClick={() => deleteTransaction(t.id)} className="trash-btn">🗑️</button>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

const TransactionForm = ({ type, onAdd }) => {
  const [form, setForm] = useState({ title: '', amount: '', date: '', category: '', reference: '' });

  const handleAdd = (e) => {
    e.preventDefault();
    if (!form.title || !form.amount || !form.date) return;
    onAdd({ ...form, id: Date.now(), type });
    setForm({ title: '', amount: '', date: '', category: '', reference: '' });
  };

  return (
    <form className="entry-form" onSubmit={handleAdd}>
      <input type="text" placeholder={`${type === 'income' ? 'Salary' : 'Expense'} Title`} value={form.title} onChange={e => setForm({...form, title: e.target.value})} />
      <input type="number" placeholder="Amount" value={form.amount} onChange={e => setForm({...form, amount: e.target.value})} />
      <div className="cal-wrapper">
        <input type="date" value={form.date} onChange={e => setForm({...form, date: e.target.value})} />
      </div>
      <select value={form.category} onChange={e => setForm({...form, category: e.target.value})}>
        <option value="">Select Option</option>
        <option value="Salary">Salary</option>
        <option value="Bitcoin">Bitcoin</option>
        <option value="Shopify">Shopify</option>
        <option value="Youtube">Youtube</option>
        <option value="Medical">Medical</option>
        <option value="Travel">Travel</option>
      </select>
      <textarea placeholder="Add A Reference" value={form.reference} onChange={e => setForm({...form, reference: e.target.value})} />
      <button type="submit" className="add-action-btn">+ Add {type}</button>
    </form>
  );
};

export default App;